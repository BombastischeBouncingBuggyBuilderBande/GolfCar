# Book Preloader

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/mdMydQO](https://codepen.io/jkantner/pen/mdMydQO).

A looping 3D-ish book animation that could act as a preloader.

Update: 10/18/21: Forgot viewport meta